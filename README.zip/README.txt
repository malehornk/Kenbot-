hello! so you want to install kenbot?
HERES HOW!!!1!!

1. make sure python 3.11 or greater is installed
2. run the following command in command prompt: pip install install pywin32 winshell torch transformers pyttsx3 requests pygame
3. double click the file "kenbot_installer.py"
4. CHANGE THE DRIVE LETTER OF THE SOURCE FOLDER ACCORDINGLY (example if your source drive for kenbot ,aka the one where the installer is , is drive E:/ then change the source folder from "F:/kenbot/versions" to "E:/kenbot/versions" do the same for any other drive letter you may have
5. choose an install directory
6.click install
7. run the new shortcut on your desktop
8. choose the version you want
9. enjoy!



TROUBLESHOOTING:

1. when installing you get a "access is denied' or other related error 
answer: change your install directory!

2. it says "F:/kenbot/versions directory not found" or other not found error
answer: you messed up the directory / didn't change letter

3. it says module no found
answer: you didn't run the command silly!

3. any other error/ error fixes not working?
answer: contact me on discord! username @thefreakyrizzl3r

