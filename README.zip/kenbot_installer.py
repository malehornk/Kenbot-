import os
import shutil
import tkinter as tk
from tkinter import filedialog, messagebox
import sys
import winshell
from win32com.client import Dispatch

# --- Default directories ---
DEFAULT_SOURCE = r"F:\kenbot\versions"
DEFAULT_TARGET = r"C:\Program Files\KenBot"

# --- Shortcut creation ---
def create_shortcut(target_dir):
    try:
        desktop = winshell.desktop()
        launcher_path = os.path.join(target_dir, "launch", "launch.py")

        shell = Dispatch("WScript.Shell")
        shortcut = shell.CreateShortCut(os.path.join(desktop, "KenBot Launcher.lnk"))
        shortcut.Targetpath = sys.executable
        shortcut.Arguments = f'"{launcher_path}"'
        shortcut.WorkingDirectory = os.path.dirname(launcher_path)
        shortcut.IconLocation = sys.executable
        shortcut.save()
        messagebox.showinfo("KenBot Installer", "Desktop shortcut created successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to create shortcut:\n{e}")

# --- Installation logic ---
def install():
    src = source_var.get().strip()
    dst = target_var.get().strip()

    if not os.path.exists(src):
        messagebox.showerror("Error", f"Source folder not found:\n{src}")
        return
    if not dst:
        messagebox.showerror("Error", "Please select an installation directory.")
        return

    try:
        # --- Create install directory if it doesn't exist ---
        if not os.path.exists(dst):
            os.makedirs(dst)
            messagebox.showinfo("KenBot Installer", f"Created install directory:\n{dst}")

        # --- Copy files recursively ---
        for root, dirs, files in os.walk(src):
            rel_path = os.path.relpath(root, src)
            target_dir = os.path.join(dst, rel_path)
            os.makedirs(target_dir, exist_ok=True)
            for file in files:
                src_file = os.path.join(root, file)
                dst_file = os.path.join(target_dir, file)
                shutil.copy2(src_file, dst_file)

        # --- Create desktop shortcut ---
        create_shortcut(dst)
        messagebox.showinfo("KenBot Installer", f"KenBot installed successfully to:\n{dst}")

    except Exception as e:
        messagebox.showerror("Installation Failed", str(e))

# --- GUI setup ---
root = tk.Tk()
root.title("KenBot Installer 98 DX")
root.geometry("420x260")
root.configure(bg="#C0C0C0")  # classic gray look
root.resizable(False, False)

title = tk.Label(root, text="KenBot Installer v4.4.3", font=("MS Sans Serif", 14, "bold"), bg="#C0C0C0")
title.pack(pady=8)

# Source field
tk.Label(root, text="Source Folder:", bg="#C0C0C0").pack(anchor="w", padx=20)
source_var = tk.StringVar(value=DEFAULT_SOURCE)
tk.Entry(root, textvariable=source_var, width=45).pack(padx=20)
tk.Button(root, text="Browse", command=lambda: source_var.set(filedialog.askdirectory()), bg="#E0E0E0", width=10).pack(pady=3)

# Target field
tk.Label(root, text="Install To:", bg="#C0C0C0").pack(anchor="w", padx=20)
target_var = tk.StringVar(value=DEFAULT_TARGET)
tk.Entry(root, textvariable=target_var, width=45).pack(padx=20)
tk.Button(root, text="Browse", command=lambda: target_var.set(filedialog.askdirectory()), bg="#E0E0E0", width=10).pack(pady=3)

# Install button
tk.Button(root, text="Install KenBot", command=install, bg="#E0E0E0", width=20).pack(pady=10)
tk.Label(root, text="© KEN technologies 2025", bg="#C0C0C0", font=("MS Sans Serif", 8)).pack(side="bottom", pady=5)

root.mainloop()
