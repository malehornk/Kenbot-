from flask import Flask, render_template, request, session, redirect, url_for
from uuid import uuid4
from kenbot import chat_with_bot, get_ascii_art  # your existing kenbot.py

app = Flask(__name__)
app.secret_key = "replace_this_with_a_secure_random_string"  # change for production

@app.before_request
def ensure_user_id():
    # Give each visitor a stable per-session user id so chat_with_bot can use per-user memory
    if "user_id" not in session:
        session["user_id"] = str(uuid4())

@app.route("/", methods=["GET"])
def index():
    intro = get_ascii_art() if hasattr(__import__("kenbot"), "get_ascii_art") else ""
    return render_template("index.html", intro=intro, history=session.get("history", []))

@app.route("/send", methods=["POST"])
def send():
    user_text = request.form.get("user_input", "").strip()
    if not user_text:
        return redirect(url_for("index"))

    user_id = session["user_id"]
    # Call your kenbot's chat function. Pass user_id so it uses per-user memory (if implemented).
    try:
        response = chat_with_bot(user_text, user_id=user_id)
    except TypeError:
        # fallback if chat_with_bot doesn't accept user_id
        response = chat_with_bot(user_text)

    # Save the exchange to session history (so page can display conversation)
    history = session.get("history", [])
    history.append({"who": "You", "text": user_text})
    history.append({"who": "KenBot", "text": response})
    # keep history reasonably small
    session["history"] = history[-40:]
    return redirect(url_for("index"))

@app.route("/reset", methods=["POST"])
def reset():
    # Clear this visitor's session conversation (does not touch server-side kenbot memory)
    session.pop("history", None)
    # If kenbot supports a reset_user_memory(user_id) function you can call it here:
    try:
        from kenbot import reset_user_memory
        reset_user_memory(session.get("user_id"))
    except Exception:
        pass
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
