import discord
from discord import app_commands
from discord.ext import commands
from kenbot_se import chat_with_bot  # import your KenBot AI brain

TOKEN = "MTM5MjI5MzM0NjI1NjQ4NjQ3MA.G0uQj2.VM-f1HuBNR3IwKljoi14EedrWmg-UHFifbVowE"

# set up bot with message intents
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"KenBot Discord App is online as {bot.user} 🧠")
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} command(s)")
    except Exception as e:
        print(f"Error syncing commands: {e}")

# Slash command: /kenbot
@bot.tree.command(name="kenbot", description="Chat with KenBot (brainrot included).")
async def kenbot_chat(interaction: discord.Interaction, message: str):
    await interaction.response.defer(thinking=True)
    response = chat_with_bot(message)
    await interaction.followup.send(f"**KenBot:** {response}")

# Slash command: /kenhelp
@bot.tree.command(name="kenhelp", description="Show KenBot help and info.")
async def kenbot_help(interaction: discord.Interaction):
    await interaction.response.send_message(
        "💿 **KenBot Help** 💿\n"
        "• `/kenbot <message>` — talk to KenBot anywhere!\n"
        "• `/kenhelp` — show this message.\n\n"
        "KenBot works in DMs, group chats, and any server that allows third-party apps 😎"
    )

bot.run(TOKEN)

