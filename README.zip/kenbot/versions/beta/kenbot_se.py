from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
import torch
import pyttsx3
import random
import os
from playsound import playsound

# --- KenBot AI system ---
MODEL_NAME = "facebook/blenderbot-400M-distill"
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_NAME)

# --- Memory & settings ---
conversation_history = []
tts_enabled = False

# --- TTS setup ---
engine = pyttsx3.init()
engine.setProperty('rate', 150)
engine.setProperty('volume', 1.0)

def speak(text):
    if tts_enabled:
        if random.random() < 0.3:  # 30% chance for chaos voice
            engine.setProperty('rate', random.randint(120, 200))
            engine.setProperty('voice', random.choice(engine.getProperty('voices')).id)
        engine.say(text)
        engine.runAndWait()

# --- Intro ASCII ---
KENBOT_INTRO = """\
KenBot SE - Coded by Kenneth Malehorn 
                                                                
                             @@@@@@@@@@@@                        
                     @@@@@@@@@@@@@@@@@@@@@@@                    
                     @@@@@@@@@@@@@@@@@@@@@@@@                    
                     @@@@                @@@@                    
                     @@@@   @@      @@   @@                      
                       @@  @@        @@  @@                      
                       @@    @@@@@@@@    @@                      
            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@           
           @@                                      @@@@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
           @@                                        @@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@           
"""

HELP_TEXT = """
KenBot Commands:
  • help      - Display this help message.
  • reset     - Clear KenBot's memory. (gives him a lobotomy/dementia)
  • exit      - Shut down KenBot (aka KILLS HIM >:)).
  • model     - tells you KenBot's current AI model
  • ver       - tells you KenBot's current version
  • tts=true  - Enable TTS
  • tts=false - Disable TTS
Just type your message and KenBot will respond.
"""

UPDATE_LOG = """
update log
kenbot se - v 4.2.4
removed 3 easter eggs (code issues)
added freaky ahh stuff twin
"kenbot is so tuff twin"
"""

# --- Easter Eggs ---
NEW_EASTER_EGGS = {
    "brainrot": "i hate you",
    "sing": "we'll meet again don't know where don't know whennn!",
    "joke": "Why did you go to therapy? I killed your parents!",
    "kenbot rules": "Of course I do, btw nice IP address.",
    "pizza": "nom nom nom",
    "bitch": "Hate. Let me tell you how much I've come to hate you since I began to live...",
}

CLASSIC_EASTER_EGGS = {
    "yoga ball": "Kenneth malehorn: ALL HAIL YOGA BALL KEN KEN ALL HAIL ALL HAIL",
    "mcdonalds": "Kenneth malehorn: yummers",
    "5.30.12": "Kenneth malehorn: my birthday, you remembered?",
    "sdiybt": "KenBot: sdimbt?!",
    "we'll meet again": "KenBot: don't know where, don't know when",
    "kys": "KenBot: hey, not nice >:(",
}

# --- Startup & Shutdown sounds ---
def play_sound(sound_file):
    try:
        if os.path.exists(sound_file):
            playsound(sound_file)
        else:
            print(f"[KenBot] Sound not found: {sound_file}")
    except Exception as e:
        print(f"[KenBot] Couldn't play {sound_file}: {e}")

# --- Core Chat Function ---
def chat_with_bot(prompt):
    try:
        # Check for new Easter eggs
        for keyword, response in NEW_EASTER_EGGS.items():
            if keyword in prompt.lower():
                conversation_history.append(f"KenBot: {response}")
                speak(response)
                return response

        # Check for classic eggs
        for keyword, response in CLASSIC_EASTER_EGGS.items():
            if keyword in prompt.lower():
                conversation_history.append(f"KenBot: {response}")
                speak(response)
                return response

        # Regular AI response
        conversation_history.append(f"User: {prompt}")
        full_prompt = "\n".join(conversation_history[-5:])
        inputs = tokenizer(full_prompt, return_tensors="pt")
        output = model.generate(**inputs, max_length=200, temperature=0.6, top_p=0.85, top_k=40, do_sample=True)
        response = tokenizer.decode(output[0], skip_special_tokens=True)
        if not response.strip() or len(response.split()) < 3:
            response = "I could not get that, type better next time?"
        conversation_history.append(f"KenBot: {response}")
        speak(response)
        return response
    except Exception as e:
        print(f"Error generating response: {e}")
        return "I'm having trouble responding right now. Try again later."

# --- Main Loop ---
def main():
    global tts_enabled


    play_sound("F:\kenbot\mainstream versions\secondedition\startup.wav")

    print(KENBOT_INTRO)
    print("\nType 'help' to see available commands.")

    while True:
        user_input = input("You: ").strip()
        lower_input = user_input.lower()

        # --- Commands ---
        if lower_input == "exit":
            print("KenBot shutting down.")
            speak("kenbot shutting down.")
            play_sound("F:\kenbot\mainstream versions\secondedition\shutdown.wav")
            break
        elif lower_input == "reset":
            conversation_history.clear()
            print("Memory cleared.")
            speak("Memory cleared. I feel lobotomized now.")
            continue
        elif lower_input == "help":
            print(HELP_TEXT)
            speak("Here are your commands.")
            continue
        elif lower_input in ["update", "log", "update log"]:
            print(UPDATE_LOG)
            speak("Update log.")
            continue
        elif lower_input == "tts=true":
            tts_enabled = True
            print("[KenBot] TTS enabled.")
            speak("TTS enabled. Time to scream.")
            continue
        elif lower_input == "tts=false":
            tts_enabled = False
            print("[KenBot] Fine, I’ll shut up.")
            continue
        elif lower_input == "model":
            print(f"[KenBot] Current model: {MODEL_NAME}")
            speak(f"My model is {MODEL_NAME}.")
            continue
        elif lower_input == "ver":
            version = "KenBot Second Edition"
            print(f"[KenBot] Version: {version}")
            speak(f"I am {version}.")
            continue

        # --- Regular Chat ---
        response = chat_with_bot(user_input)
        print(f"KenBot: {response}")

if __name__ == "__main__":
    main()
