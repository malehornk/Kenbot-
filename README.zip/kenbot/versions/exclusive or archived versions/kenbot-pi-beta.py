from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
import torch

# Load a lighter model optimized for Raspberry Pi 5
MODEL_NAME = "facebook/blenderbot-90M"
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_NAME)

# Move model to appropriate device (CPU or GPU if available)
device = "cuda" if torch.cuda.is_available() else "cpu"
model = model.to(device).half()  # Use float16 for efficiency

def chat_with_bot(prompt, chat_history=None):
    """Generate a conversational response using BlenderBot-90M for efficiency."""
    try:
        if chat_history:
            context = " \n".join(chat_history[-3:])  # Keep last 3 exchanges as context
            prompt = f"{context}\nUser: {prompt}\nKenBot:"  # Format input properly
        
        inputs = tokenizer(prompt, return_tensors="pt", truncation=True, padding=True).to(device)
        output = model.generate(**inputs, max_length=100, do_sample=True, temperature=0.7, top_p=0.9, top_k=40)
        response = tokenizer.decode(output[0], skip_special_tokens=True)
        
        # Improved filtering for gibberish and irrelevant responses
        if not response.strip() or len(response.split()) < 3:
            response = "I'm not sure I understand. Can you clarify?"
        
        return response
    except Exception as e:
        print(f"Error generating response: {e}")
        return "I'm having trouble responding right now. Try again later."

def main():
    print("KenBot v4 Pi Edition coded by ChatGPT and Kenneth Malehorn")
    print("""
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⠶⠚⠛⠉⠉⠉⠀⠀⠉⠉⠙⠓⠦⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⠴⠶⠦⢤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠳⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡿⠛⠛⠒⢦⡀⠀⠀⠉⠙⠳⢶⣤⣄⣀⣀⣀⣀⣀⣤⠜⢷⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡏⠀⠀⠀⠀⠀⠹⣄⠀⠀⢀⠔⠋⠉⠉⠛⢍⠉⠉⣽⠃⠀⢀⣻⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⡤⢾⡇⠀⠀⣸⣧⠤⢤⣏⠉⠙⡏⠀⠀⢀⣀⠀⠈⣧⠴⣷⠶⠾⣿⡟⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⠟⠁⠀⠀⠹⣄⡼⠋⠀⠀⠀⠈⠁⠀⣧⠀⠀⠈⠁⠀⢠⡇⠀⠀⠀⠀⢻⠷⠛⣷⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡟⠁⠀⠀⠀⠀⠀⠀⢳⡄⠀⠀⠀⠀⠀⠀⠈⠳⢄⣀⣀⠴⠋⠀⠀⠀⠀⠀⠀⠀⠀⠸⣇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢠⡿⠀⠀⠀⠀⠀⠀⢀⡤⠀⠉⠓⠦⠤⠤⠖⠀⠀⠀⠀⠀⠀⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡄⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣼⠁⠀⠀⠀⠀⠀⠀⣨⠧⣄⣀⡀⠀⠀⠀⠀⠀⢀⣀⣠⡤⠶⠛⡧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣧⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠻⣤⣄⡈⠉⠉⠉⠉⠉⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣷⠀⠀⠀⠀⠀⠀⠀⠀⣴⠋⠉⠀⠀⠀⠀⠀⠀⠀⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠀⠀⠀⠀
""")
    print("Type 'exit' to shut down KenBot.")
    chat_history = []
    
    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            print("KenBot shutting down.")
            break
        
        response = chat_with_bot(user_input, chat_history)
        chat_history.append(f"User: {user_input}")
        chat_history.append(f"KenBot: {response}")
        
        print(f"KenBot: {response}")

if __name__ == "__main__":
    main()
