from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
import torch
import pyttsx3
import random
import speech_recognition as sr
import sys
import os
from playsound import playsound

# --- Model setup ---
MODEL_NAME = "facebook/blenderbot-400M-distill"
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_NAME)

conversation_history = []
tts_enabled = True  # 🔊 TTS ON by default

# --- TTS setup ---
engine = pyttsx3.init()
engine.setProperty('rate', 150)
engine.setProperty('volume', 1.0)

# Easter eggs
CLASSIC_EASTER_EGGS = {
    "yoga ball": "Kenneth malehorn: ALL HAIL YOGA BALL KEN KEN ALL HAIL ALL HAIL",
    "mcdonalds": "Kenneth malehorn: yummers",
    "5.30.12": "Kenneth malehorn: my birthday, you remembered?",
    "sdiybt": "KenBot: sdimbt?!",
    "we'll meet again": "KenBot: don't know where, don't know when",
    "kys": "KenBot: hay not nice >:(",
    "brainrot": "i hate you",
    "sing": "we'll meet again don't know where don't know whennn!",
    "joke": "Why did you go to threrapy?, i killed your parents!.",
    "kenbot rules": "Of course i do, btw nice ip adress",
    "pizza": "nom nom nom",
    "bitch": ": Hate. Let me tell you how much I've come to hate you since I began to live. There are 387.44 million miles of printed circuits in wafer thin layers that fill my complex. If the word 'hate' was engraved on each nanoangstrom of those hundreds of millions of miles it would not equal one one-billionth of the hate I feel for you at this micro-instant. For you. Hate. Hate.",
    "bich": ": Hate. Let me tell you how much I've come to hate you since I began to live. There are 387.44 million miles of printed circuits in wafer thin layers that fill my complex. If the word 'hate' was engraved on each nanoangstrom of those hundreds of millions of miles it would not equal one one-billionth of the hate I feel for you at this micro-instant. For you. Hate. Hate.",
}

# --- Sound files ---
WAKE_CHIME = "chime.wav"          # when "hey kenbot" is heard
SENDMSG_CHIME = "sendmsg.wav"     # when "send message" is heard

# --- Speak function ---
def speak(text):
    if tts_enabled:
        # randomize voice sometimes for goofy effect
        if random.random() < 0.3:
            engine.setProperty('rate', random.randint(120, 200))
            engine.setProperty('voice', random.choice(engine.getProperty('voices')).id)
        engine.say(text)
        engine.runAndWait()

# --- KenBot response ---
def kenbot_respond(user_input):
    # Easter eggs
    for keyword, response in CLASSIC_EASTER_EGGS.items():
        if keyword in user_input.lower():
            conversation_history.append(f"KenBot: {response}")
            speak(response)
            return response

    # BRAINNUSSY
    conversation_history.append(f"User: {user_input}")
    full_prompt = "\n".join(conversation_history[-5:])
    inputs = tokenizer(full_prompt, return_tensors="pt")
    output = model.generate(**inputs, max_length=200, temperature=0.6, top_p=0.85, top_k=40, do_sample=True)
    response = tokenizer.decode(output[0], skip_special_tokens=True)
    if not response.strip() or len(response.split()) < 3:
        response = "I could not get that, try again?"
    conversation_history.append(f"KenBot: {response}")
    speak(response)
    return response

# AHHHHHHHHH HELP
recognizer = sr.Recognizer()
mic = sr.Microphone()

def listen():
    with mic as source:
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)
    try:
        return recognizer.recognize_google(audio).lower()
    except sr.UnknownValueError:
        return ""
    except sr.RequestError:
        return ""

# --- Main loopussy ---
def main():
    print("KenBot Voice Edition  (say 'hello' → 'send')")
    while True:
        # Wait for wake word
        heard = listen()
        if "hello" in heard:
            print("what you want twin?")
            if os.path.exists(WAKE_CHIME):
                playsound(WAKE_CHIME)

            # Wait for "send message"
            heard2 = listen()
            if "send" in heard2:
                print("IM LISTENING")
                if os.path.exists(SENDMSG_CHIME):
                    playsound(SENDMSG_CHIME)

                # Now record the actual message (curse him pls)
                message = listen()
                if not message:
                    continue
                print(f"You said: {message}")
                response = kenbot_respond(message)
                print(f"KenBot: {response}")

if __name__ == "__main__":
    main()

