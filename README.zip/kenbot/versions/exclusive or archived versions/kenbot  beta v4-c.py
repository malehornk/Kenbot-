﻿from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
import torch


# Load a more advanced conversational model from Hugging Face
MODEL_NAME = "facebook/blenderbot-400M-distill"
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_NAME)


KENBOT_INTRO = """\
KenBot v4 - Coded by ChatGPT and Kenneth Malehorn 


                              ╔█████████████████                                                                                                          
                             █████████████████████
                             ███              ╫██▌
                             ╜██   ▓█    ╒█   ╟█▀└
                              ╟█              ╟█
                              ╟█   ╜█▄▄▄▄╢█   ╟█
                              ╫█     ╙╙╙╙     ╫█
                     ┌╫▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█▄
                   ▄█▀                                  ▀║█
                   ████████████████████████████████████████▒
                   ██                                    ╟█▒
                   ████████████████████████████████████████▒
                   ██                                    ║█▒
                   ██▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄██▒
                   ██╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙╙║█▒
                   ██╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓╓║█▒
                   ██▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀██▒
                   ██                                    ║█▒
                   ████████████████████████████████████████▒
                   ██                                    ▐█▒
                   ████████████████████████████████████████▒
                   ██                                    ▐█▒
                   ████████████████████████████████████████▒
                     ▀▌▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█▌
                      ╙▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
"""


def chat_with_bot(prompt):
    """Generate a conversational response using BlenderBot for improved coherence."""
    try:
        inputs = tokenizer(prompt, return_tensors="pt")
        
        # Enable sampling and apply temperature, top_p, and top_k
        output = model.generate(**inputs, max_length=150, temperature=0.6, top_p=0.85, top_k=40, do_sample=True)
        response = tokenizer.decode(output[0], skip_special_tokens=True)
        
        # Improved filtering for gibberish and irrelevant responses
        if not response.strip() or len(response.split()) < 3 or "I'm sorry" in response:
            response = "I'm not sure I understand. Can you clarify?"
        
        return response
    except Exception as e:
        print(f"Error generating response: {e}")
        return "I'm having trouble responding right now. Try again later."


def main():
    print(KENBOT_INTRO)
    print("\nType 'exit' to shut down KenBot.")
    
    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            print("KenBot shutting down.")
            break
        response = chat_with_bot(user_input)
        print(f"KenBot: {response}")


if __name__ == "__main__":
    main()