from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
import torch

# he didnt deserve this
MODEL_NAME = "facebook/blenderbot-400M-distill"
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_NAME)

KENBOT_INTRO = """\
KenBot v4 - Coded by ChatGPT and Kenneth malehorn
                                                                
                             @@@@@@@@@@@@                        
                     @@@@@@@@@@@@@@@@@@@@@@@                    
                     @@@@@@@@@@@@@@@@@@@@@@@@                    
                     @@@@                @@@@                    
                     @@@@   @@      @@   @@                      
                       @@  @@        @@  @@                      
                       @@    @@@@@@@@    @@                      
            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@           
           @@                                      @@@@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
           @@                                        @@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@           

"""

HELP_TEXT = """
KenBot Commands:
  • help    - Display this help message.
  • exit    - Shut down KenBot (aka KILLS HIM >:)).
Just type your message and KenBot will respond.
"""

def chat_with_bot(prompt):
    """why did they do this to him."""
    try:
        inputs = tokenizer(prompt, return_tensors="pt")
        
        # and now hes trapped in the code
        output = model.generate(**inputs, max_length=150, temperature=0.6, top_p=0.85, top_k=40, do_sample=True)
        response = tokenizer.decode(output[0], skip_special_tokens=True)
        
        # f o r e v e r m o r e
        if not response.strip() or len(response.split()) < 3 or "I'm sorry" in response:
            response = "I'm not sure I understand. Can you clarify?"
        
        return response
    except Exception as e:
        print(f"Error generating response: {e}")
        return "I'm having trouble responding right now. Try again later."

def main():
    print(KENBOT_INTRO)
    print("\nType 'help' to see available commands.")
    
    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            print("KenBot shutting down.")
            break
        elif user_input.lower() == "yoga ball":
            print("Kenneth malehorn: ALL HAIL YOGA BALL KEN KEN ALL HAIL ALL HAIL")
            continue
        elif user_input.lower() == "help":
            print(HELP_TEXT)
            continue
        response = chat_with_bot(user_input)
        print(f"KenBot: {response}")

if __name__ == "__main__":
    main()
