from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
import torch

MODEL_NAME = "facebook/blenderbot-400M-distill"
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_NAME)

device = "cuda" if torch.cuda.is_available() else "cpu"
model.to(device)

chat_history = []

def chat_with_bot(prompt):
    try:
        # Include last 3 messages for context
        context = " \n".join(chat_history[-3:]) if chat_history else ""
        full_prompt = f"{context}\nUser: {prompt}\nKenBot:"

        inputs = tokenizer(full_prompt, return_tensors="pt", truncation=True, padding=True).to(device)
        output = model.generate(
            **inputs,
            max_length=150,
            do_sample=True,
            temperature=0.7,
            top_p=0.9,
            top_k=40
        )
        response = tokenizer.decode(output[0], skip_special_tokens=True)

        # Filter gibberish or too short responses
        if not response.strip() or len(response.split()) < 3 or "I'm sorry" in response:
            response = "I'm not sure I understand. Can you clarify?"

        # Add to chat history
        chat_history.append(f"User: {prompt}")
        chat_history.append(f"KenBot: {response}")

        return response
    except Exception as e:
        print(f"Error generating response: {e}")
        return "I'm having trouble responding right now."

def main():
    print("just type he will respond!")
    print("Type 'exit' to quit.")
    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            print("KenBot shutting down.")
            break
        response = chat_with_bot(user_input)
        print(f"KenBot: {response}")

if __name__ == "__main__":
    main()
