from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
import torch

# Load a more advanced conversational model from Hugging Face
MODEL_NAME = "facebook/blenderbot-400M-distill"
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_NAME)

DIALTONE_INTRO = """\
dialtone - coded by ????????//????????
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⠶⠚⠛⠉⠉⠉⠀⠀⠉⠉⠙⠓⠦⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡿⠛⠛⠒⢦⡀⠀⠀⠉⠙⠳⢶⣤⣄⣀⣀⣀⣀⣀⣤⠜⢷⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡏⠀⠀⠀⠀                                                             ⠀⠹⣄⠀⠀⢀⠔⠋⠉⠉⠛⢍⠉⠉⣽⠃⠀⢀⣻⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⡤⢾⡇⠀⠀⣸⣧⠤⢤⣏⠉⠙⡏⠀⠀⢀⣀⠀⠈⣧⠴⣷⠶⠾⣿⡟⣿⡀⠀⠀⠀⠈⠁⠀⢠⡇⠀⠀⠀⠀⢻⠷⠛⣷⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡇⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢀                   ⣤⠞⠻⣆⠀⠙⢷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠉⠀⠀⣠⡾⠁⠀⠀⠀⠀⠀⠈
⠀⠀⣀⡴⠟⠁⠀⠀⠙⢧⡀⠀⠉⠻⢦⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⠴⠖⠛⠉⠀⠀⢀⣤⠞⠉⠀⠀⠀⠀⠀⠀⠀⠀
⣤⠞⠋⠀                                    ⠀⠀⠀⠀⠀⠀⠻⣦⡀⠀⠀⠈⠛⢶⣄⠀⠀⠀⠀⠀⣀⣤⠴⠖⠛⠉⠁⠀⠀⠀⠀⣀⡤⠖⠋⠀⠀⠀⠀⠀⠀⠀    ⠀⠀⠀⠀
"""

def chat_with_bot(prompt):
    """Generate a conversational response using BlenderBot for improved coherence."""
    try:
        inputs = tokenizer(prompt, return_tensors="pt")
        
        # Enable sampling and apply temperature, top_p, and top_k
        output = model.generate(**inputs, max_length=150, temperature=0.6, top_p=0.85, top_k=40, do_sample=True)
        response = tokenizer.decode(output[0], skip_special_tokens=True)
        
        # Improved filtering for gibberish and irrelevant responses
        if not response.strip() or len(response.split()) < 3 or "I'm sorry" in response:
            response = "I'm not sure I understand. [[Can you clarify]]?"
        
        return response
    except Exception as e:
        print(f"Error generating response: {e}")
        return "I'm having trouble responding right now. Try again later."

def main():
    print(DIALTONE_INTRO)
    print("\nType '????' to shut down dialtone.")
    
    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            print("dialtone s hutti ng                        do wn.")
            break
        if user_input.lower() == "ybkk":
            print("H  a TT e.")
            break
        if user_input.lower() == "kenbot":
            print("YOUU  [[BROTHER]]")
            break
        if user_input.lower() == "ybbot":
            print(" HI I I  I POOKI E E E.")
            break
        if user_input.lower() == "what happened":
            print("????????????????????????")
            break
        if user_input.lower() == "what happened":
            print("????????????????????????")
            break
        if user_input.lower() == "whats wrong":
            print("????????????????????????")
            break
        if user_input.lower() == "whats wrong?":
            print("????????????????????????")
            break
        if user_input.lower() == "ken ken":
            print("DA DAhahah")
            break
        if user_input.lower() == "dialtone":
            print("dialtone: thats s s me-e-e-e-e!")
            continue
        if user_input.lower() == "dialtone?":
            print("dialtone: thats s s me-e-e-e-e!")
            continue
        if user_input.lower() == "are you ok?":
            print("dialtone: IM M M PREFECTY [[100% freshly picked]] I HAVE [[0% ideas]] WHAT YOU ARE [[conversing]] ABOUT")
            continue
        if user_input.lower() == "are you ok":
            print("dialtone: IM M M PREFECTY [[100% freshly picked]] I HAVE [[0% ideas]] WHAT YOU ARE [[conversing]] ABOUT")
            continue
        if user_input.lower() == "ybkksane teto":
            print("dialtone: [[teto word of the day!: ]]  help me")
            continue
        if user_input.lower() == "evil ken ken":
            print("Hate. Let me tell you how much I've come to hate [[evil ken ken]] since I began to live. There are 387.44 million miles of printed circuits in wafer thin layers that fill my complex. If the word 'hate' was engraved on each nanoangstrom of those hundreds of millions of miles it would not equal one one-billionth of the hate I feel for [[evil ken ken]] at this micro-instant. For [[evil ken ken]]. Hate. Hate.")
            break
        response = chat_with_bot(user_input)
        print(f"dialtone: {response}")

if __name__ == "__main__":
    main()
