import os
import subprocess
import tkinter as tk
from tkinter import filedialog, messagebox

# Default directory (same as installer target)
DEFAULT_DIR = r"PUT DIRECTORY HERE OR BROWSE"

def find_kenbots(search_dir):
    """Scan for any .py file with 'kenbot' in the name."""
    bots = []
    for root, _, files in os.walk(search_dir):
        for f in files:
            if f.lower().startswith("kenbot") and f.endswith(".py"):
                bots.append(os.path.join(root, f))
    return bots

def browse_dir():
    """Let the user select another directory."""
    folder = filedialog.askdirectory(title="Select KenBot Directory")
    if folder:
        dir_var.set(folder)
        refresh_list()

def launch_bot(path):
    """Launch the selected KenBot version."""
    try:
        subprocess.Popen(["python", path], cwd=os.path.dirname(path))
        messagebox.showinfo("KenBot Launcher", f"Launching {os.path.basename(path)}...")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to launch {path}\n{e}")

def refresh_list():
    """Refresh displayed KenBot versions."""
    for widget in bot_frame.winfo_children():
        widget.destroy()

    directory = dir_var.get().strip()
    if not os.path.exists(directory):
        tk.Label(bot_frame, text="⚠️ Directory not found.", bg="#C0C0C0").pack()
        return

    bots = find_kenbots(directory)
    if not bots:
        tk.Label(bot_frame, text="⚠️ No KenBot versions found.", bg="#C0C0C0").pack()
    else:
        for bot_path in bots:
            frame = tk.Frame(bot_frame, bg="#C0C0C0")
            frame.pack(fill="x", padx=10, pady=2)
            tk.Label(frame, text=os.path.basename(bot_path), bg="#C0C0C0").pack(side="left", padx=5)
            tk.Button(frame, text="Launch", command=lambda p=bot_path: launch_bot(p),
                      bg="#E0E0E0", width=10).pack(side="right", padx=5)

# --- GUI Setup ---
root = tk.Tk()
root.title("KenBot Launcher 98 Ultra Deluxe")
root.geometry("450x300")
root.configure(bg="#C0C0C0")
root.resizable(False, False)

title = tk.Label(root, text="KenBot Launcher 98 Ultra Deluxe", font=("MS Sans Serif", 14, "bold"), bg="#C0C0C0")
title.pack(pady=8)

tk.Label(root, text="Directory:", bg="#C0C0C0").pack(anchor="w", padx=20)
dir_var = tk.StringVar(value=DEFAULT_DIR)
tk.Entry(root, textvariable=dir_var, width=50).pack(padx=20)
tk.Button(root, text="Browse", command=browse_dir, bg="#E0E0E0", width=10).pack(pady=3)

# scrollable frame for KenBots
bot_canvas = tk.Canvas(root, bg="#C0C0C0", highlightthickness=0)
bot_frame = tk.Frame(bot_canvas, bg="#C0C0C0")
scrollbar = tk.Scrollbar(root, orient="vertical", command=bot_canvas.yview)
bot_canvas.configure(yscrollcommand=scrollbar.set)

scrollbar.pack(side="right", fill="y")
bot_canvas.pack(fill="both", expand=True, padx=15)
bot_canvas.create_window((0, 0), window=bot_frame, anchor="nw")

def on_configure(event):
    bot_canvas.configure(scrollregion=bot_canvas.bbox("all"))
bot_frame.bind("<Configure>", on_configure)

tk.Button(root, text="Refresh", command=refresh_list, bg="#E0E0E0", width=12).pack(pady=6)
tk.Label(root, text="© KenBot Launcher 1998 Ultra Deluxe", bg="#C0C0C0", font=("MS Sans Serif", 8)).pack(side="bottom", pady=4)

refresh_list()
root.mainloop()

