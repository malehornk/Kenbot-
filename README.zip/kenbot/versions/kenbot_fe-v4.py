from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
import torch

# KenBot's brain ig
MODEL_NAME = "facebook/blenderbot-400M-distill"
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_NAME)

# Memory stuff
conversation_history = []

KENBOT_INTRO = """\
KenBot v4 - Coded by ChatGPT and Kenneth malehorn
                                                                
                             @@@@@@@@@@@@                        
                     @@@@@@@@@@@@@@@@@@@@@@@                    
                     @@@@@@@@@@@@@@@@@@@@@@@@                    
                     @@@@                @@@@                    
                     @@@@   @@      @@   @@                      
                       @@  @@        @@  @@                      
                       @@    @@@@@@@@    @@                      
            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@           
           @@                                      @@@@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
           @@                                        @@          
           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          
           @@                                        @@          
            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@           
"""

HELP_TEXT = """
KenBot Commands:
  • help    - Display this help message.
  • reset   - Clear KenBot's memory. (gives him a lobotomy/dementia)
  • exit    - Shut down KenBot (aka KILLS HIM >:)).
  • model - tells you kenbots current ai model
  • ver     - tells you kenbots current version
Just type your message and KenBot will respond.
"""

def chat_with_bot(prompt):
    try:
        # more memory stuff
        conversation_history.append(f"User: {prompt}")

        # more fucking memory shit
        full_prompt = "\n".join(conversation_history[-5:])  # Limit memory to last 5 lines

        inputs = tokenizer(full_prompt, return_tensors="pt")
        output = model.generate(**inputs, max_length=200, temperature=0.6, top_p=0.85, top_k=40, do_sample=True)
        response = tokenizer.decode(output[0], skip_special_tokens=True)

        if not response.strip() or len(response.split()) < 3:
            response = "I could not get that , type better next time?"

        # WHY IS THERE SO MUCH MEMORY SHIT OMG
        conversation_history.append(f"KenBot: {response}")

        return response
    except Exception as e:
        print(f"Error generating response: {e}")
        return "I'm having trouble responding right now. Try again later."

def get_ascii_art():
    return KENBOT_INTRO

def main():
    print(KENBOT_INTRO)
    print("\nType 'help' to see available commands.")

    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            print("KenBot shutting down.")
            break
        elif user_input.lower() == "reset":
            conversation_history.clear()
            print("Memory cleared.")
            continue
        elif user_input.lower() == "yoga ball":
            print("Kenneth malehorn: ALL HAIL YOGA BALL KEN KEN ALL HAIL ALL HAIL")
            continue
        elif user_input.lower() == "mcdonalds":
            print("Kenneth malehorn: yummers")
            continue
        elif user_input.lower() == "5.30.12":
            print("Kenneth malehorn: my birthday, you remembered?")
            continue
        elif user_input.lower() == "sdiybt":
            print("KenBot: sdimbt?!")
            continue
        elif user_input.lower() == "we'll meet again":
            print("KenBot: don't know where, don't know when")
            continue
        elif user_input.lower() == "kys":
            print("KenBot:h hoe you need to kill yo self stanky ahh")
            continue
        elif user_input.lower() == "model":
            print(MODEL_NAME)
            continue
        elif user_input.lower() == "ver":
            print(KENBOT_INTRO)
            continue
        elif user_input.lower() == "help":
            print(HELP_TEXT)
            continue
        response = chat_with_bot(user_input)
        print(f"KenBot: {response}")

if __name__ == "__main__":
    main()

